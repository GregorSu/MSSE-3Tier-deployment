$ESLZPrefix = "DEV-MXDR"
$Location = "westeurope"
$DeploymentName = "GregorSu-MXDR"

# Added next lines for DEV GregorSu environment
# $TenantRootGroupId = (Get-AzTenant).Id
$TenantRootGroupId = "a343d0df-132c-4f1a-b739-d1319eb013ae"
$PlatformSubscriptionId = "389a8786-8225-400e-9557-7802ca4093ff"
$Customer01subscription = "4be3677f-1aa8-4000-8654-060b9e9826c9"  
$SecurityContactEmailAddress = "admin@m365x391662.onmicrosoft.com"

# I do not have the rest of the data...
# $ConnectivitySubscriptionId = "<replace me>"
# $ConnectivityAddressPrefix = "<replace me>"
# $IdentitySubscriptionId = "<replace me>"
# $CorpConnectedLandingZoneSubscriptionId = "<replace me>" 
# $OnlineLandingZoneSubscriptionId = "<replace me>"

# # Deploy management groups...
# New-AzManagementGroupDeployment -Name $DeploymentName `
#                                 -ManagementGroupId $TenantRootGroupId `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-mgmtGroups.json" `
#                                 -topLevelManagementGroupPrefix $ESLZPrefix `
#                                 -Verbose
#                                 
# # Deploy Policies...
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-policies-MXDRRoot" `
#                                 -ManagementGroupId $ESLZPrefix `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-policies-TEMP.json" `
#                                 -topLevelManagementGroupPrefix $ESLZPrefix `
#                                 -Verbose
# 
# # Deploy policy initiative for preventing usage of public endpoint for Azure PaaS services
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-Policy-DenyPublicEndpoints" `
#                                 -ManagementGroupId $ESLZPrefix `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MDXR-DENY-PublicEndpointsPolicySetDefinition.json" `
#                                 -Verbose
# 
# # Deploying policy initiative for associating private DNS zones with private endpoints for Azure PaaS services
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-Policy-PrivateDNSEndpoints" `
#                                 -ManagementGroupId $ESLZPrefix `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MDXR-DINE-PrivateDNSZonesPolicySetDefinition.json" `
#                                 -Verbose
# 
# # Add dedicated subscription for platform management
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-ManagementSubscription" `
#                                 -ManagementGroupId "$($ESLZPrefix)-Platform" `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-subscriptionOrganization.json" `
#                                 -targetManagementGroupId "$($ESLZPrefix)-Platform" `
#                                 -subscriptionId $PlatformSubscriptionId `
#                                 -Verbose
# 
# 
# # Deploy Log Analytics Workspace to the MXDR platform subscription
# Select-AzSubscription -SubscriptionName $PlatformSubscriptionId
# New-AzSubscriptionDeployment -Name "$($DeploymentName)-LogAnalytics" `
#                              -Location $Location `
#                              -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-logAnalyticsWorkspace.json" `
#                              -rgName "$($ESLZPrefix)-Management" `
#                              -workspaceName "$($ESLZPrefix)-law" `
#                              -workspaceRegion $Location `
#                              -retentionInDays "180" `
#                              -automationAccountName "$($ESLZPrefix)-aauto" `
#                              -automationRegion $Location `
#                              -Verbose
# 
# # Deploy Log Analytics Solutions to the Log Analytics workspace in the MXDR platform subscription
# # I've tested the Solutions, deployment works, but I am not sure if we actually need them all. Every solution in the JSON is enabled, but
# # we can also disable some of them.
# Select-AzSubscription -SubscriptionName $PlatformSubscriptionId
# New-AzSubscriptionDeployment -Name "$($DeploymentName)-LA-Solution" `
#                              -Location $Location `
#                              -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-logAnalyticsSolutions.json" `
#                              -rgName "$($ESLZPrefix)-Management" ` `
#                              -workspaceName "$($ESLZPrefix)-law" `
#                              -workspaceRegion $Location `
#                              -Verbose                             
# 
# # Assign Azure Policy to enforce Log Analytics workspace on the MXDR Platform Subscription, assignment is created on Subscription level
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-LA-Policy" `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DINE-LogAnalyticsPolicyAssignment.json" `
#                                 -retentionInDays "180" `
#                                 -rgName "$($ESLZPrefix)-Management" `
#                                 -ManagementGroupId "$($eslzPrefix)-Platform" `
#                                 -topLevelManagementGroupPrefix $ESLZPrefix `
#                                 -logAnalyticsWorkspaceName "$($ESLZPrefix)-law" `
#                                 -workspaceRegion $Location `
#                                 -automationAccountName "$($ESLZPrefix)-aauto" `
#                                 -automationRegion $Location `
#                                 -Verbose
# 
# # Assign Azure Policy (initiative, already created before) to enforce diagnostic settings for subscriptions on top level management group
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-Sub-EnforceDiagSettings" `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DINE-ActivityLogPolicyAssignment.json" `
#                                 -topLevelManagementGroupPrefix $ESLZPrefix `
#                                 -logAnalyticsResourceId "/subscriptions/$($PlatformSubscriptionId)/resourceGroups/$($eslzPrefix)-Platform/providers/Microsoft.OperationalInsights/workspaces/$($eslzPrefix)-law" `
#                                 -ManagementGroupId $ESLZPrefix `
#                                 -Verbose
# 
# # Assign Azure Policy (initiative, already created before) to enforce diagnostic settings for subscriptions on top level management group
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-Resource-DiagSettings" `
#                                -Location $Location `
#                                -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DINE-ResourceDiagnosticsPolicyAssignment.json" `
#                                -topLevelManagementGroupPrefix $ESLZPrefix `
#                                -logAnalyticsResourceId "/subscriptions/$($PlatformSubscriptionId)/resourceGroups/$($eslzPrefix)-Platform/providers/Microsoft.OperationalInsights/workspaces/$($eslzPrefix)-law" `
#                                -ManagementGroupId $ESLZPrefix `
#                                -Verbose
# 
# # Assign Azure Policy to enforce Microsoft Defender for Cloud configuration enabled on all subscriptions, deployed to top level management group
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-DefenderForCloud-Enforcement" `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DINE-ASCConfigPolicyAssignment.json" `
#                                 -ManagementGroupId $eslzPrefix `
#                                 -topLevelManagementGroupPrefix $ESLZPrefix `
#                                 -logAnalyticsResourceId "/subscriptions/$($PlatformSubscriptionId)/resourceGroups/$($eslzPrefix)-Platform/providers/Microsoft.OperationalInsights/workspaces/$($eslzPrefix)-law" `
#                                 -enableAscForServers "DeployIfNotExists" `
#                                 -enableAscForSql "DeployIfNotExists" `
#                                 -enableAscForAppServices "DeployIfNotExists" `
#                                 -enableAscForStorage "DeployIfNotExists" `
#                                 -enableAscForRegistries "DeployIfNotExists" `
#                                 -enableAscForKeyVault "DeployIfNotExists" `
#                                 -enableAscForSqlOnVm "DeployIfNotExists" `
#                                 -enableAscForKubernetes "DeployIfNotExists" `
#                                 -enableAscForArm "DeployIfNotExists" `
#                                 -enableAscForDns "DeployIfNotExists" `
#                                 -enableAscForOssDb "DeployIfNotExists" `
#                                 -emailContactAsc $SecurityContactEmailAddress `
#                                 -Verbose
# 
# # Assign Azure Policy to enable Azure Security Benchmark, deployed to top level management group
# New-AzManagementGroupDeployment -Name "$($DeploymentName)-AzureSecurityBenchmark" `
#                                 -Location $Location `
#                                 -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DINE-ASBPolicyAssignment.json" `
#                                 -ManagementGroupId $ESLZPrefix `
#                                 -Verbose


# Assign Azure Policy to prevent public IP usage in the (identity) Management subscription (GregorSu: I will NOT use IDENTITY subscription, Managemnent Instead and also CustomerX)
New-AzManagementGroupDeployment -Name "$($DeploymentName)-Deny-Public-IP-Platform" `
                                -Location $Location `
                                -ManagementGroupId "$($ESLZPrefix)-Platform" `
                                -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DENY-PublicIpAddressPolicyAssignment.json" `
                                -topLevelManagementGroupPrefix $ESLZPrefix `
                                -Verbose

New-AzManagementGroupDeployment -Name "$($DeploymentName)-Deny-Public-IP-Customer1" `
                                -Location $Location `
                                -ManagementGroupId "$($ESLZPrefix)-Customer1" `
                                -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DENY-PublicIpAddressPolicyAssignment.json" `
                                -topLevelManagementGroupPrefix $ESLZPrefix `
                                -Verbose

# Assign Azure Policy to deny RDP access from internet into VMs (domain controllers) in the (identity) ALL subscriptions
New-AzManagementGroupDeployment -Name "$($DeploymentName)-Deny-RDP" `
                                -Location $Location `
                                -ManagementGroupId "$($ESLZPrefix)" `
                                -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DENY-RDPFromInternetPolicyAssignment.json" `
                                -topLevelManagementGroupPrefix $eslzPrefix `
                                -Verbose

# Assign Azure Policy to deny usage of storage accounts over http everywhere 
New-AzManagementGroupDeployment -Name "$($DeploymentName)-DenyStorage-HTTP" `
                                -Location $Location `
                                -ManagementGroupId "$($ESLZPrefix)" `
                                -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DENY-StorageWithoutHttpsPolicyAssignment.json" `
                                -Verbose

# Assign Azure Policy to enforce TLS/SSL on the landing zones management group
New-AzManagementGroupDeployment -Name "$($DeploymentName)-Enforce-TLS-SSL" `
                                -Location $Location `
                                -ManagementGroupId "$($ESLZPrefix)" `
                                -TemplateFile "C:\Users\Administrator.CORP\Desktop\MXDR - PS\Policies\MXDR-DENY-DINE-Append-TLS-SSL-PolicyAssignment.json" `
                                -topLevelManagementGroupPrefix $eslzPrefix `
                                -Verbose
