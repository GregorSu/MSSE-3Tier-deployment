#Connect-AzAccount

# Using Coustomer1 subscription (MG)
Set-AzContext -Subscription '4be3677f-1aa8-4000-8654-060b9e9826c9'

#sign in to Azure from Powershell, this will redirect you to a webbrowser for authentication, if required
Connect-AzAccount

#get object Id of the current user (that is used above)
$user = Get-AzADUser -UserPrincipalName (Get-AzContext).Account

#assign Owner role at Tenant root scope ("/") as a User Access Administrator to current user
New-AzRoleAssignment -Scope '/' -RoleDefinitionName 'Owner' -ObjectId $user.Id

#(optional) assign Owner role at Tenant root scope ("/") as a User Access Administrator to service principal (set $spndisplayname to your service principal displayname)
$spndisplayname = "<ServicePrincipal DisplayName>"
$spn = (Get-AzADServicePrincipal -DisplayName $spndisplayname).id
New-AzRoleAssignment -Scope '/' -RoleDefinitionName 'Owner' -ObjectId $spn


$ManagementSubscriptionId = "389a8786-8225-400e-9557-7802ca4093ff"
$Customer1SubscriptionId = "4be3677f-1aa8-4000-8654-060b9e9826c9"  

Select-AzSubscription -SubscriptionName $ManagementSubscriptionId
#Remove Policy assignments
Get-AzPolicyAssignment | Remove-AzPolicyAssignment -Verbose

#Delete Custom Initiatives
Get-AzPolicySetDefinition -Custom | Remove-AzPolicySetDefinition -Force

#Delete all Custom Policies
Get-AzPolicyDefinition -Custom | Remove-AzPolicyDefinition -Force

$Customer1SubscriptionId = "4be3677f-1aa8-4000-8654-060b9e9826c9"
Select-AzSubscription -SubscriptionName $Customer1SubscriptionId 
Get-AzResourceGroup | Remove-AzResourceGroup -Force -Verbose 

# Delete Resource Groups in subscription (if you have more subscriptions, command needs to be run on all of them)
$ManagementSubscriptionId = "389a8786-8225-400e-9557-7802ca4093ff"
Select-AzSubscription -SubscriptionName $ManagementSubscriptionId 
Get-AzResourceGroup | Remove-AzResourceGroup -Force -Verbose   

# Evaluate Policy and resorces for Partner1 subscription
 $subscriptionId = "4be3677f-1aa8-4000-8654-060b9e9826c9"
 $uri = "https://management.azure.com/subscriptions/$subscriptionId/providers/Microsoft.PolicyInsights/policyStates/latest/triggerEvaluation?api-version=2018-07-01-preview"
 $azContext = Get-AzContext
 $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
 $profileClient = New-Object -TypeName Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient -ArgumentList ($azProfile)
 $token = $profileClient.AcquireAccessToken($azContext.Tenant.Id)
 $authHeader = @{
     'Content-Type'='application/json'
     'Authorization'='Bearer ' + $token.AccessToken }
 Invoke-RestMethod -Method Post -Uri $uri -UseBasicParsing -Headers $authHeader -Debug

 # Evaluate Policy and resorces for Platform subscription
 $subscriptionId = "389a8786-8225-400e-9557-7802ca4093ff"
 $uri = "https://management.azure.com/subscriptions/$subscriptionId/providers/Microsoft.PolicyInsights/policyStates/latest/triggerEvaluation?api-version=2018-07-01-preview"
 $azContext = Get-AzContext
 $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
 $profileClient = New-Object -TypeName Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient -ArgumentList ($azProfile)
 $token = $profileClient.AcquireAccessToken($azContext.Tenant.Id)
 $authHeader = @{
     'Content-Type'='application/json'
     'Authorization'='Bearer ' + $token.AccessToken }
 Invoke-RestMethod -Method Post -Uri $uri -UseBasicParsing -Headers $authHeader -Debug